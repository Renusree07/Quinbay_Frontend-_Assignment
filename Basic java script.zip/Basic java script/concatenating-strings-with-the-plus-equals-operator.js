var myStr="This is the first sentence. ";

 myStr += "This is the second sentence.";