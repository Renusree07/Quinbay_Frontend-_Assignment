function randomFraction() {
  return Math.random();
}

  // Only change code above this line
