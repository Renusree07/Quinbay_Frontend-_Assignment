// Only change code below 
var myArray = [[1,2],[3,4]];