function functionWithArgs(num1, num2){
  console.log(num1+num2);
}
functionWithArgs(1,2);