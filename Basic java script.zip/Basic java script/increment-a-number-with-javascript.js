let myVar = 87;

// Only change code below this line
myVar++