// Setup
var a;
a = 7;
var b;




b = a; 