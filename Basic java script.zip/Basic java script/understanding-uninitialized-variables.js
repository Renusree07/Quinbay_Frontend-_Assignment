// Only change code below this line
var a;
var b;
var c;
// Only change code above this line
a=5;
b=10;
c="I am a";

a = a + 1;
b = b + 5;
c = c + " String!";