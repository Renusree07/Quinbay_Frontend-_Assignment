const FCC = "freeCodeCamp"; // Change this line
 let fact = "is cool!"; // Change this line
fact = "is awesome!";
console.log(FCC, fact); // Change this line