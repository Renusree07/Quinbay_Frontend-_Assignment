function checkEqual(a, b) {
  return a === b ? "Equal" : "Not Equal";
}