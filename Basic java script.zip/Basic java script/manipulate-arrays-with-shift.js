var myArray = [["John", 23], ["dog", 3]];

// Only change code below this line.
var removedFromMyArray=myArray.shift();