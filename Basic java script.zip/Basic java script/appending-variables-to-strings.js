// Change code below this line
var someAdjective="cool";
var myStr = "Learning to code is ";
myStr+= someAdjective;