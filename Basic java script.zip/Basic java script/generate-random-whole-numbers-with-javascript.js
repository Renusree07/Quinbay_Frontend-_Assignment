function randomWholeNum() {
  return Math.floor(Math.random() * 10);
}