var myFirstName = "Renu";
var myLastName= "sree"