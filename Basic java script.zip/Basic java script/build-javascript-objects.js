const myDog = {
  // Only change code below this line
"name": "puffy",
  "legs": 4,
  "tails": 1,
  "friends": ["watson", "kat"]
  

  // Only change code above this line
};