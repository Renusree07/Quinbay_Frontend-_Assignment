const myArray = [];
let i = 5;
while (i >= 0) {
  myArray.push(i);
  i--;
}