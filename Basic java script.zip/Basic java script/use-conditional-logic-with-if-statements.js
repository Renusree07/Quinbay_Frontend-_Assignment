function trueOrFalse(wasThatTrue) {
  // Only change code below this line


 if (wasThatTrue) { 
    return "Yes, that was true";
  }
  return "No, that was false";
  
  
  // Only change code above this line.

}
  