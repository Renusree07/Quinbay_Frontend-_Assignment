function convertToInteger(str) {
  return parseInt(str, 2);
}