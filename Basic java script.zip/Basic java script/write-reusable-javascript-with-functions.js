function reusableFunction(){
    console.log("Hi World");
}
reusableFunction();