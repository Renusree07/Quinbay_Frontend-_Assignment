// Example
var ourArray = [];

for (var i = 0; i < 5; i++) {
  ourArray.push(i);
}

// Setup
var myArray = [];

// Only change code below this line.


for (var i = 0; i < 5; i++) {
  myArray.push(i+1);
}