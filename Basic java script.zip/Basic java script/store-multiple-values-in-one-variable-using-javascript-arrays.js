// Only change code below 
var myArray = ["test string",777];