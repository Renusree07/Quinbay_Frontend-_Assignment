var myList = [];

myList=[["item-1",1],["item-2",2],["item-3",3],["item-4",4],["item-5",5]];