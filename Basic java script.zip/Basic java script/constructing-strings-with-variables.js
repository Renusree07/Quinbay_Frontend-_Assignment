// Only change code below this line
var myName="Anuj";
var myStr="My name is "+myName+" and i am well!";