function isLess(a, b) {
  // Only change code below t
  
    return a < b;
  // Only change code above this line
}

isLess(10, 15);