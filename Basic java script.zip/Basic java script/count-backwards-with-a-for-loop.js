const myArray = [];
for (let i = 9; i > 0; i -= 2) {
  myArray.push(i);
}