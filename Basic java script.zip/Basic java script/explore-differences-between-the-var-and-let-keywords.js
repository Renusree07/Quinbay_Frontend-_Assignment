let catName = "Oliver";
let catSound = "Meow!";
console.log(catName);