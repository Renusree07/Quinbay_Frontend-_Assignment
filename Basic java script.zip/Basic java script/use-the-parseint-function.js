function convertToInteger(str) {
  return parseInt(str);
}