const myArray = [];
for (let i = 1; i < 10; i += 2) {
  myArray.push(i);
}